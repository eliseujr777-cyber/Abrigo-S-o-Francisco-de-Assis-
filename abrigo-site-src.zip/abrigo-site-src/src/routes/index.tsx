import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowDown, ArrowUpRight, Heart, PawPrint, MapPin, Star, Utensils, Syringe, Stethoscope, Scissors, Share2, Check, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { PIX_KEY } from "@/lib/pix";
import animalPhoto from "@/assets/abrigo-animais.jpg";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Abrigo São Francisco de Assis Taquara — Doe amor" },
    { name: "description", content: "Ajude o Abrigo São Francisco de Assis, em Taquara, com alimentação, vacinas, castração e tratamento veterinário para cães e gatos." },
    { property: "og:title", content: "Abrigo São Francisco de Assis — Uma nova chance começa com você" },
    { property: "og:description", content: "Faça parte desta corrente de cuidado. Apoie a alimentação e a saúde dos animais do abrigo em Taquara." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Fundraiser,
});

const care = [
  { icon: Utensils, title: "Alimentação", text: "Ração e alimento para manter cães e gatos nutridos, todos os dias.", tone: "food" },
  { icon: Syringe, title: "Vacinas", text: "Proteção contra doenças para uma vida mais saudável e segura.", tone: "vaccine" },
  { icon: Scissors, title: "Castração", text: "Cuidado responsável para ajudar a interromper o ciclo de abandono.", tone: "neuter" },
  { icon: Stethoscope, title: "Tratamento veterinário", text: "Consultas, medicamentos e cuidados para quem precisa se recuperar.", tone: "vet" },
];

function PixKeyCard() {
  const [copied, setCopied] = useState(false);
  const [copyFailed, setCopyFailed] = useState(false);

  async function copyKey() {
    try {
      await navigator.clipboard.writeText(PIX_KEY);
      setCopied(true);
      setCopyFailed(false);
    } catch {
      setCopyFailed(true);
    }
  }

  return (
    <div className="rounded-lg border border-border bg-card p-6">
      <p className="section-label">PIX DO ABRIGO</p>
      <p className="mt-3 text-sm leading-relaxed text-muted-foreground">Chave para receber doações. Copie e cole no app do seu banco.</p>
      <p className="mt-4 select-all rounded-md bg-secondary/70 px-4 py-4 text-center font-mono text-xl font-bold break-all tracking-[0.08em] text-foreground">{PIX_KEY}</p>
      <Button onClick={copyKey} className="mt-4 h-12 w-full text-base">{copied ? <Check /> : <Copy />}{copied ? "Chave copiada!" : "Copiar chave Pix"}</Button>
      {copyFailed && <p role="status" className="mt-3 text-center text-xs text-muted-foreground">Não foi possível copiar automaticamente. Selecione a chave acima e copie manualmente.</p>}
    </div>
  );
}

export function Fundraiser() {
  const [donateOpen, setDonateOpen] = useState(false);
  const [shared, setShared] = useState(false);
  const [shareError, setShareError] = useState(false);
  async function share() {
    try {
      if (navigator.share) {
        await navigator.share({ title: "Ajude o Abrigo São Francisco de Assis", text: "Uma nova chance começa com você. Apoie os animais do abrigo em Taquara.", url: window.location.href });
      } else {
        await navigator.clipboard.writeText(window.location.href);
      }
      setShared(true);
      setShareError(false);
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") return;
      setShareError(true);
    }
  }
  return (
    <main>
      <header className="border-b border-border bg-background">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-6 py-5 lg:px-10">
          <a href="#inicio" aria-label="Abrigo São Francisco de Assis, início" className="flex items-center gap-3">
            <span className="flex size-11 shrink-0 items-center justify-center rounded-full bg-secondary text-primary"><PawPrint size={25} /></span>
            <span className="text-sm font-bold leading-snug">São Francisco de Assis<span className="block text-xs font-normal text-muted-foreground">ABRIGO DE ANIMAIS · TAQUARA</span></span>
          </a>
          <nav aria-label="Navegação principal" className="hidden items-center gap-8 text-sm font-semibold md:flex">
            <a href="#causa" className="hover:text-primary">Nossa causa</a>
            <a href="#cuidados" className="hover:text-primary">Sua ajuda transforma</a>
            <a href="#doar" className="hover:text-primary">Como doar</a>
          </nav>
          <Button onClick={() => setDonateOpen(true)} className="h-11 px-5"><Heart /> Quero doar</Button>
        </div>
      </header>

      <section id="inicio" className="fundraiser-hero relative isolate overflow-hidden">
        <img src={animalPhoto} alt="Imagem ilustrativa de um cão e um gato juntos em um jardim" width={1536} height={1024} className="absolute inset-0 -z-20 h-full w-full object-cover" />
        <div className="hero-shade absolute inset-0 -z-10" />
        <div className="mx-auto max-w-7xl px-6 py-16 lg:px-10 lg:py-20">
          <div className="hero-copy max-w-xl text-hero-foreground">
            <p className="mb-6 flex items-center gap-2 text-xs font-bold uppercase tracking-[0.12em]"><span className="h-2 w-2 rounded-full bg-accent" /> Uma corrente de amor e cuidado</p>
            <h1 className="font-display text-4xl leading-[1.1] sm:text-5xl lg:text-6xl">Abrigo São<br className="hidden sm:block" /> Francisco de Assis</h1>
            <p className="mt-5 flex items-center gap-2 text-sm text-hero-muted"><MapPin size={16} /> Taquara · Acolhimento e adoção de animais</p>
            <p className="mt-7 max-w-sm text-lg leading-relaxed text-hero-muted">Uma nova chance começa com você. Ajude a transformar abandono em cuidado, saúde e esperança.</p>
            <Button onClick={() => setDonateOpen(true)} size="lg" className="mt-8 h-13 px-7 text-base"><Heart /> Quero ajudar os animais <ArrowUpRight /></Button>
            <p className="mt-4 text-xs text-hero-muted">Todo gesto importa. Todo amor faz diferença.</p>
          </div>
        </div>
        <span className="absolute bottom-4 right-6 text-[10px] text-hero-foreground/80">Imagem ilustrativa</span>
      </section>

      <div className="border-b border-border bg-background">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-5 px-6 py-6 lg:px-10">
          <div className="flex items-center gap-4"><span className="text-3xl font-bold">4,1<span className="text-base font-normal text-muted-foreground"> / 5</span></span><div><div className="flex gap-1 text-rating" aria-label="4,1 de 5 estrelas">{[1, 2, 3, 4, 5].map(n => <Star key={n} size={15} fill={n <= 4 ? "currentColor" : "none"} />)}</div><p className="mt-1 text-xs text-muted-foreground">88 avaliações no Google</p></div></div>
          <p className="text-sm text-muted-foreground">Uma causa que une pessoas e muda vidas.</p>
          <a href="#causa" className="flex items-center gap-2 text-sm font-semibold text-primary">Conheça nossa causa <ArrowDown size={16} /></a>
        </div>
      </div>

      <section id="causa" className="mx-auto grid max-w-7xl gap-8 px-6 py-16 md:grid-cols-[0.85fr_1.15fr] md:gap-20 lg:px-10 lg:py-20">
        <div><p className="section-label">POR ELES. COM VOCÊ.</p><h2 className="mt-4 max-w-md font-display text-4xl leading-tight">Eles só precisam de uma nova chance.</h2><Heart className="mt-7 text-primary" size={30} strokeWidth={1.3} /></div>
        <div className="space-y-5 text-base leading-relaxed text-muted-foreground"><p className="text-lg font-semibold text-foreground">Eles já foram abandonados, doentes e ignorados. Agora só precisam de você.</p><p>O Abrigo São Francisco de Assis, em Taquara, acolhe cães e gatos e ajuda cada um a encontrar uma nova família. Com 4,1 estrelas e 88 avaliações no Google, o serviço de adoção conta com o apoio de pessoas que acreditam nessa causa.</p><p>As doações ajudam com alimentação diária, vacinas, castração e tratamento veterinário. São cuidados essenciais para que cada animal possa se recuperar, viver com dignidade e ter a chance de ser adotado.</p><p>Não existe valor pequeno. Cada contribuição se soma a outras e se transforma em cuidado de verdade.</p><p className="font-semibold text-primary">Doe agora e ajude a transformar a vida de um animal.</p></div>
      </section>

      <section id="cuidados" className="bg-secondary/60 px-6 py-16 lg:px-10">
        <div className="mx-auto max-w-7xl"><div className="flex flex-wrap items-end justify-between gap-5"><div><p className="section-label">ONDE SEU AMOR CHEGA</p><h2 className="mt-4 font-display text-3xl sm:text-4xl">Sua doação vira cuidado.</h2></div><p className="max-w-xs text-sm leading-relaxed text-muted-foreground">Necessidades reais. Gestos que fazem a diferença na vida de cães e gatos.</p></div>
          <div className="mt-9 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{care.map(item => <article key={item.title} className="rounded-lg border border-border bg-card p-6"><span className={`care-icon care-${item.tone} inline-flex size-12 items-center justify-center rounded-lg`}><item.icon size={23} strokeWidth={1.6} /></span><h3 className="mt-6 text-base font-bold">{item.title}</h3><p className="mt-3 text-sm leading-relaxed text-muted-foreground">{item.text}</p></article>)}</div>
        </div>
      </section>

      <section id="doar" className="mx-auto grid max-w-7xl items-start gap-10 px-6 py-16 md:grid-cols-[1.1fr_0.9fr] md:gap-16 lg:px-10 lg:py-20">
        <div>
          <p className="section-label">COMO DOAR</p>
          <h2 className="mt-4 font-display text-3xl leading-tight sm:text-4xl">Doe em segundos pelo Pix.</h2>
          <p className="mt-5 max-w-md text-base leading-relaxed text-muted-foreground">Você escolhe o valor. Cada real se transforma em ração, vacina, castração ou tratamento para os animais do abrigo.</p>
          <ol className="mt-8 space-y-4 text-sm leading-relaxed">
            <li className="flex gap-4"><span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-secondary text-xs font-bold text-primary">1</span><span className="pt-1">Copie a chave Pix ao lado.</span></li>
            <li className="flex gap-4"><span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-secondary text-xs font-bold text-primary">2</span><span className="pt-1">Abra o app do seu banco e escolha <span className="font-semibold text-foreground">Pix</span>.</span></li>
            <li className="flex gap-4"><span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-secondary text-xs font-bold text-primary">3</span><span className="pt-1">Cole a chave, defina o valor e confirme a doação.</span></li>
          </ol>
        </div>
        <PixKeyCard />
      </section>

      <section className="bg-primary px-6 py-16 text-center text-primary-foreground"><PawPrint className="mx-auto mb-5" size={32} strokeWidth={1.5} /><h2 className="font-display text-3xl sm:text-4xl">Um pequeno gesto.<br />Uma vida inteira de diferença.</h2><p className="mx-auto mt-5 max-w-lg text-sm leading-relaxed">Ajude a manter essa corrente de cuidado. Doe e compartilhe a causa com quem também ama os animais.</p><div className="mt-7 flex flex-wrap justify-center gap-3"><Button variant="secondary" className="h-12 px-7" onClick={() => setDonateOpen(true)}><Heart /> Quero doar</Button><Button variant="outline" className="h-12 px-6 text-primary" onClick={share}>{shared ? <Check /> : <Share2 />}{shared ? "Compartilhado!" : "Compartilhar a causa"}</Button></div>{shareError && <p role="status" className="mt-4 text-sm">Não foi possível compartilhar. Copie o endereço da página no navegador.</p>}</section>
      <footer className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-6 py-8 text-xs text-muted-foreground lg:px-10"><span className="flex items-center gap-2"><PawPrint size={18} /> Abrigo São Francisco de Assis · Taquara</span><span>Feito por amor aos animais.</span></footer>
      <Dialog open={donateOpen} onOpenChange={setDonateOpen}><DialogContent className="max-w-md"><DialogHeader><span className="mb-4 flex size-12 items-center justify-center rounded-full bg-secondary text-primary"><Heart /></span><DialogTitle className="font-display text-2xl">Obrigado por querer ajudar!</DialogTitle><DialogDescription className="pt-3 text-base leading-relaxed">Doe pelo Pix usando a chave abaixo. O valor é você quem escolhe.</DialogDescription></DialogHeader><PixKeyCard /><Button variant="outline" onClick={share}><Share2 /> {shared ? "Link copiado ou compartilhado" : "Compartilhar a causa"}</Button>{shareError && <p role="status" className="text-sm text-muted-foreground">Copie o endereço da página para compartilhar.</p>}</DialogContent></Dialog>
    </main>
  );
}
