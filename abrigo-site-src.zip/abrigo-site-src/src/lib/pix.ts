// Pix key supplied by the shelter for receiving donations.
export const PIX_KEY = "21053373767";
