import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";

import { PIX_KEY } from "@/lib/pix";
import { Fundraiser } from "@/routes/index";

// The donation key must stay exactly as the shelter supplied it: a mistyped
// digit would silently send every donation to the wrong account.
describe("Pix donation", () => {
  it("keeps the supplied Pix key unchanged", () => {
    expect(PIX_KEY).toBe("21053373767");
  });

  it("shows the Pix key and a copy button on the page", () => {
    render(<Fundraiser />);

    expect(screen.getAllByText("21053373767").length).toBeGreaterThan(0);
    expect(screen.getByRole("button", { name: /copiar chave pix/i })).toBeInTheDocument();
  });
});
